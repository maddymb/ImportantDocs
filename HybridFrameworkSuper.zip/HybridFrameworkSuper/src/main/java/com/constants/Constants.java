package com.constants;

public class Constants {

	public static long PAGE_LOAD_TIME=20;
	public static long IMLPLICIT_WAIT=20;
	public static String TESTDATA_SHEET_PATH="/Users/maddy/eclipse-workspace/Hybrid-Framework-FreeCRM/src/main/java/com/freecrm/testdata/FreeCrmTestData.xlsx";
	
	
}
