package com.pages;

public class WelcomePage {

}
