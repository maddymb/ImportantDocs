// 
// Decompiled by Procyon v0.5.36
// 

package atu.alm.wrapper;

import atu.alm.wrapper.classes.StepFactory;

public interface ITestCaseRun extends HasAttachmentFeature
{
    StepFactory getStepFactory();
}
