// 
// Decompiled by Procyon v0.5.36
// 

package atu.alm.wrapper;

public interface ITestSet extends HasAttachmentFeature
{
}
