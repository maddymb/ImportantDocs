// 
// Decompiled by Procyon v0.5.36
// 

package atu.alm.wrapper.bean;

public class ServerDetails
{
    private String url;
    private String username;
    private String password;
    private String domain;
    private String project;
    
    public String getUrl() {
        return this.url;
    }
    
    public void setUrl(final String url) {
        this.url = url;
    }
    
    public String getUsername() {
        return this.username;
    }
    
    public void setUsername(final String username) {
        this.username = username;
    }
    
    public String getPassword() {
        return this.password;
    }
    
    public void setPassword(final String password) {
        this.password = password;
    }
    
    public String getDomain() {
        return this.domain;
    }
    
    public void setDomain(final String domain) {
        this.domain = domain;
    }
    
    public String getProject() {
        return this.project;
    }
    
    public void setProject(final String project) {
        this.project = project;
    }
}
