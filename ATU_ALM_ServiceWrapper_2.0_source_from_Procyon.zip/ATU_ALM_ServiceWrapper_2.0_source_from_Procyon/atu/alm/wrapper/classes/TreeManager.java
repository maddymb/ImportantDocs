// 
// Decompiled by Procyon v0.5.36
// 

package atu.alm.wrapper.classes;

import com.jacob.activeX.ActiveXComponent;

class TreeManager
{
    public TreeManager(final ActiveXComponent almObject) {
    }
}
