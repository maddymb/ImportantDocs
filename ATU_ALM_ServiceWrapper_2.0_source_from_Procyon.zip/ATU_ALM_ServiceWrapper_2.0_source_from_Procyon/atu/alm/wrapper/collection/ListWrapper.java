// 
// Decompiled by Procyon v0.5.36
// 

package atu.alm.wrapper.collection;

import java.util.ArrayList;

public class ListWrapper<Object> extends ArrayList<Object>
{
    public int getCount() {
        return this.size();
    }
}
